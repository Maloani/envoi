<?php 
require_once 'vendor/autoload.php';
	if (isset($_POST['submit'])) {
		$receiver=$_POST['receiver'];
		$subject=$_POST['subject'];
		$msg=$_POST['message'];

		$messagebird = new MessageBird\Client('ADdQAusxPahmNZhozFURF442z');
		$message = new MessageBird\Objects\Message;
		$message->originator = '+243995515593';
		$message->recipients = [ $receiver];
		$message->body = $msg;
		$response = $messagebird->messages->create($message);
		if ($response=true) {
			echo "<script>alert('message envoyer avec succuss')</script>";
		}else{
			echo "<script>alert('Error')</script>";
		}

	}
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>envoi</title>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
</head>
<body>
	<div class="container py-4">
		<div class="row">
			<div class="col-md-5 mx-auto bg-white shadow border p-4 rounded">
				<h2 class="text-center fw-bold mb-3">SMS Sender</h2>
                <form action="" method="post">
                     <div class="form-group mb-3">
                         <label for="receiver" class="form-label">Receiver</label>
                        <input type="text" class="form-control" placeholder="Enter receiver phone number" required name="receiver" id="receiver">
                    </div>
                    <div class="form-group mb-3">
                         <label for="subject" class="form-label">Subject</label>
                        <input type="text" class="form-control" placeholder="Enter subject" required name="subject" id="subject">
                    </div>
                    <div class="form-group mb-3">
                         <label for="message" class="form-label">Message</label>
                        <textarea rows="5" class="form-control" placeholder="Enter message" required name="message" id="message"></textarea>
                    </div>
                    <div>
                    	<button type="submit" class="btn btn-primary" name="submit">Send SMS</button>
                    	<button type="reset" class="btn btn-danger" >Reset form</button>
                    </div>
                </form>

            </div>
		</div>
		
	</div>

	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
</body>
</html>